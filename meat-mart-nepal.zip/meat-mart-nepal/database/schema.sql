-- ============================================================
-- MEAT MART NEPAL — PostgreSQL Database Schema
-- Run: psql -U postgres -d meatmart -f schema.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS meatmart;
\c meatmart;

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─── ROLES ───────────────────────────────────────────────
CREATE TABLE roles (
  id SERIAL PRIMARY KEY,
  name VARCHAR(50) UNIQUE NOT NULL,
  permissions JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO roles (name, permissions) VALUES
  ('admin',      '{"all": true}'),
  ('manager',    '{"sales":true,"inventory":true,"reports":true,"customers":true,"expenses":true}'),
  ('cashier',    '{"sales":true,"customers":true,"khata_collect":true}'),
  ('storekeeper','{"inventory":true,"purchases":true,"wastage":true}');

-- ─── BRANCHES ────────────────────────────────────────────
CREATE TABLE branches (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  address TEXT,
  phone VARCHAR(20),
  manager_name VARCHAR(100),
  is_active BOOLEAN DEFAULT TRUE,
  is_warehouse BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO branches (name, address, phone, manager_name, is_warehouse) VALUES
  ('Central Warehouse', 'Kalimati, Kathmandu', '01-4200000', 'Admin', TRUE),
  ('Baneshwor',         'Baneshwor Chowk, Kathmandu', '01-4234567', 'Sushil Thapa', FALSE),
  ('Kalanki',           'Kalanki Chowk, Kathmandu',   '01-4298765', 'Binod Karki', FALSE),
  ('Patan',             'Mangal Bazar, Lalitpur',      '01-5522334', 'Laxmi Shrestha', FALSE);

-- ─── USERS ───────────────────────────────────────────────
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role_id INT REFERENCES roles(id),
  branch_id INT REFERENCES branches(id),
  is_active BOOLEAN DEFAULT TRUE,
  last_login TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Default admin password: Admin@1234 (bcrypt hash)
INSERT INTO users (full_name, email, password_hash, role_id, branch_id) VALUES
  ('Prashant (Admin)', 'admin@meatmart.np',    '$2b$10$rQJ2uJ8Kp3mN5vX9yL4dOuWqZkT1aB6cD7eF8gH0iJ2kL4mN6oP8', 1, NULL),
  ('Sushil Thapa',     'sushil@meatmart.np',   '$2b$10$rQJ2uJ8Kp3mN5vX9yL4dOuWqZkT1aB6cD7eF8gH0iJ2kL4mN6oP8', 2, 2),
  ('Ram Kumar',        'ram@meatmart.np',       '$2b$10$rQJ2uJ8Kp3mN5vX9yL4dOuWqZkT1aB6cD7eF8gH0iJ2kL4mN6oP8', 3, 2),
  ('Gopal Rai',        'gopal@meatmart.np',     '$2b$10$rQJ2uJ8Kp3mN5vX9yL4dOuWqZkT1aB6cD7eF8gH0iJ2kL4mN6oP8', 4, 3),
  ('Binod Karki',      'binod@meatmart.np',     '$2b$10$rQJ2uJ8Kp3mN5vX9yL4dOuWqZkT1aB6cD7eF8gH0iJ2kL4mN6oP8', 2, 3),
  ('Laxmi Shrestha',   'laxmi@meatmart.np',     '$2b$10$rQJ2uJ8Kp3mN5vX9yL4dOuWqZkT1aB6cD7eF8gH0iJ2kL4mN6oP8', 2, 4);

-- ─── PRODUCT CATEGORIES ──────────────────────────────────
CREATE TABLE product_categories (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  slug VARCHAR(50) UNIQUE NOT NULL,
  emoji VARCHAR(10),
  sort_order INT DEFAULT 0
);

INSERT INTO product_categories (name, slug, emoji, sort_order) VALUES
  ('Chicken', 'chicken', '🐔', 1),
  ('Mutton',  'mutton',  '🐑', 2),
  ('Duck',    'duck',    '🦆', 3),
  ('Egg',     'egg',     '🥚', 4),
  ('Other',   'other',   '🍖', 5);

-- ─── PRODUCTS ────────────────────────────────────────────
CREATE TABLE products (
  id SERIAL PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  category_id INT REFERENCES product_categories(id),
  sku VARCHAR(50) UNIQUE,
  emoji VARCHAR(10) DEFAULT '🥩',
  sale_mode VARCHAR(20) DEFAULT 'weight',  -- weight, pack, both
  unit VARCHAR(20) DEFAULT 'kg',           -- kg, gram, piece, dozen, tray, pack
  sale_price NUMERIC(10,2) NOT NULL,
  purchase_cost NUMERIC(10,2),
  vat_applicable BOOLEAN DEFAULT TRUE,
  low_stock_threshold NUMERIC(10,2) DEFAULT 5,
  is_active BOOLEAN DEFAULT TRUE,
  image_url TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE product_cuts (
  id SERIAL PRIMARY KEY,
  product_id INT REFERENCES products(id) ON DELETE CASCADE,
  cut_name VARCHAR(100) NOT NULL,
  extra_charge NUMERIC(10,2) DEFAULT 0
);

-- ─── PRODUCT SEED DATA ───────────────────────────────────
INSERT INTO products (name, category_id, sku, emoji, unit, sale_price, purchase_cost, vat_applicable, low_stock_threshold) VALUES
  ('Broiler Chicken', 1, 'CHK-BRL-01', '🐔', 'kg',  450, 360, TRUE, 5),
  ('Farm Chicken',    1, 'CHK-FRM-02', '🐓', 'kg',  520, 410, TRUE, 5),
  ('Mutton',          2, 'MTN-REG-01', '🐑', 'kg',  900, 720, TRUE, 3),
  ('Goat Meat',       2, 'GMT-REG-01', '🐐', 'kg',  850, 680, TRUE, 3),
  ('Duck',            3, 'DCK-REG-01', '🦆', 'kg',  800, 620, TRUE, 3),
  ('Eggs',            4, 'EGG-REG-01', '🥚', 'piece', 15,  12, FALSE,30),
  ('Egg Tray (30)',   4, 'EGG-TRY-01', '🍳', 'tray', 165, 130, FALSE, 5),
  ('Pig Meat',        5, 'PIG-REG-01', '🐷', 'kg',  650, 500, TRUE, 3);

INSERT INTO product_cuts (product_id, cut_name) VALUES
  (1,'Curry Cut'),(1,'Boneless'),(1,'With Skin'),(1,'Mince/Keema'),(1,'Whole'),
  (2,'Whole'),(2,'Curry Cut'),(2,'Boneless'),
  (3,'Curry Cut'),(3,'Boneless'),(3,'Ribs'),(3,'Mince/Keema'),(3,'Whole'),
  (4,'Curry Cut'),(4,'Whole'),(4,'Ribs'),
  (5,'Whole'),(5,'Curry Cut'),(5,'Boneless'),
  (8,'Curry Cut'),(8,'Boneless');

-- ─── SUPPLIERS ───────────────────────────────────────────
CREATE TABLE suppliers (
  id SERIAL PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  contact_person VARCHAR(100),
  phone VARCHAR(20),
  address TEXT,
  pan_number VARCHAR(20),
  opening_balance NUMERIC(12,2) DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO suppliers (name, contact_person, phone, address) VALUES
  ('Kalimati Poultry Suppliers',  'Ram Bahadur',  '9841-100200', 'Kalimati, Kathmandu'),
  ('Kirtipur Mutton House',       'Shyam Tamang',  '9851-200300', 'Kirtipur, Kathmandu'),
  ('Bhaktapur Duck Farm',         'Hari Shrestha', '9800-300400', 'Bhaktapur'),
  ('Kathmandu Egg Suppliers',     'Gita Rai',      '9812-400500', 'Balkhu, Kathmandu');

-- ─── CUSTOMERS ───────────────────────────────────────────
CREATE TABLE customers (
  id SERIAL PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  phone VARCHAR(20),
  address TEXT,
  customer_type VARCHAR(30) DEFAULT 'retail', -- retail, household, hotel, wholesale
  branch_id INT REFERENCES branches(id),
  opening_balance NUMERIC(12,2) DEFAULT 0,
  credit_limit NUMERIC(12,2) DEFAULT 0,
  notes TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO customers (name, phone, customer_type, branch_id, credit_limit) VALUES
  ('Walk-in',         NULL,          'retail',    2, 0),
  ('Hotel Shivam',    '9841-234567', 'hotel',     2, 20000),
  ('Hotel Mount View','9851-345678', 'hotel',     2, 15000),
  ('Rajan Thapa',     '9800-111222', 'household', 2, 5000),
  ('Krishna Prasad',  '9812-567890', 'wholesale', 2, 30000),
  ('Sita Sharma',     '9845-678901', 'household', 2, 3000),
  ('Bina Rai',        '9860-789012', 'retail',    3, 0);

-- ─── PRODUCT BATCHES ─────────────────────────────────────
CREATE TABLE product_batches (
  id SERIAL PRIMARY KEY,
  batch_code VARCHAR(30) UNIQUE NOT NULL,
  product_id INT REFERENCES products(id),
  branch_id INT REFERENCES branches(id),
  supplier_id INT REFERENCES suppliers(id),
  purchase_date DATE,
  processing_date DATE,
  expiry_date DATE,
  purchase_qty NUMERIC(10,3),
  current_qty NUMERIC(10,3) DEFAULT 0,
  purchase_cost NUMERIC(10,2),
  freshness_status VARCHAR(20) DEFAULT 'fresh', -- fresh, good, expiring, expired
  is_active BOOLEAN DEFAULT TRUE,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── STOCK MOVEMENTS ─────────────────────────────────────
CREATE TABLE stock_movements (
  id SERIAL PRIMARY KEY,
  batch_id INT REFERENCES product_batches(id),
  product_id INT REFERENCES products(id),
  branch_id INT REFERENCES branches(id),
  movement_type VARCHAR(30) NOT NULL, -- purchase_in, sale_out, transfer_in, transfer_out, wastage, adjustment, staff_use
  quantity NUMERIC(10,3) NOT NULL,    -- positive = in, negative = out
  reference_type VARCHAR(30),         -- sale, purchase, transfer, manual
  reference_id INT,
  notes TEXT,
  created_by INT REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── PURCHASES ───────────────────────────────────────────
CREATE TABLE purchases (
  id SERIAL PRIMARY KEY,
  po_number VARCHAR(30) UNIQUE,
  supplier_id INT REFERENCES suppliers(id),
  branch_id INT REFERENCES branches(id),
  purchase_date DATE DEFAULT CURRENT_DATE,
  total_amount NUMERIC(12,2) DEFAULT 0,
  paid_amount NUMERIC(12,2) DEFAULT 0,
  due_amount NUMERIC(12,2) GENERATED ALWAYS AS (total_amount - paid_amount) STORED,
  payment_method VARCHAR(30),
  grn_status VARCHAR(20) DEFAULT 'pending', -- pending, received, partial
  notes TEXT,
  created_by INT REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE purchase_items (
  id SERIAL PRIMARY KEY,
  purchase_id INT REFERENCES purchases(id) ON DELETE CASCADE,
  product_id INT REFERENCES products(id),
  quantity NUMERIC(10,3) NOT NULL,
  unit_cost NUMERIC(10,2) NOT NULL,
  total_cost NUMERIC(12,2) GENERATED ALWAYS AS (quantity * unit_cost) STORED
);

-- ─── TRANSFERS ───────────────────────────────────────────
CREATE TABLE transfers (
  id SERIAL PRIMARY KEY,
  transfer_code VARCHAR(30) UNIQUE,
  from_branch_id INT REFERENCES branches(id),
  to_branch_id INT REFERENCES branches(id),
  status VARCHAR(20) DEFAULT 'pending', -- pending, approved, dispatched, received, rejected
  requested_by INT REFERENCES users(id),
  approved_by INT REFERENCES users(id),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE transfer_items (
  id SERIAL PRIMARY KEY,
  transfer_id INT REFERENCES transfers(id) ON DELETE CASCADE,
  product_id INT REFERENCES products(id),
  batch_id INT REFERENCES product_batches(id),
  quantity NUMERIC(10,3) NOT NULL
);

-- ─── SALES ───────────────────────────────────────────────
CREATE TABLE sales (
  id SERIAL PRIMARY KEY,
  invoice_number VARCHAR(30) UNIQUE,
  branch_id INT REFERENCES branches(id),
  customer_id INT REFERENCES customers(id),
  cashier_id INT REFERENCES users(id),
  sale_date TIMESTAMPTZ DEFAULT NOW(),
  subtotal NUMERIC(12,2) DEFAULT 0,
  discount_amount NUMERIC(12,2) DEFAULT 0,
  vat_amount NUMERIC(12,2) DEFAULT 0,
  total_amount NUMERIC(12,2) DEFAULT 0,
  paid_amount NUMERIC(12,2) DEFAULT 0,
  due_amount NUMERIC(12,2) GENERATED ALWAYS AS (total_amount - paid_amount) STORED,
  payment_method VARCHAR(30) DEFAULT 'cash', -- cash, bank, card, esewa, khalti, fonepay, khata
  is_khata BOOLEAN DEFAULT FALSE,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE sale_items (
  id SERIAL PRIMARY KEY,
  sale_id INT REFERENCES sales(id) ON DELETE CASCADE,
  product_id INT REFERENCES products(id),
  batch_id INT REFERENCES product_batches(id),
  cut_type VARCHAR(50),
  quantity NUMERIC(10,3) NOT NULL,
  unit_price NUMERIC(10,2) NOT NULL,
  discount NUMERIC(10,2) DEFAULT 0,
  vat_rate NUMERIC(5,2) DEFAULT 13,
  line_total NUMERIC(12,2) GENERATED ALWAYS AS (quantity * unit_price - discount) STORED
);

-- ─── CUSTOMER LEDGER ─────────────────────────────────────
CREATE TABLE customer_ledgers (
  id SERIAL PRIMARY KEY,
  customer_id INT REFERENCES customers(id),
  branch_id INT REFERENCES branches(id),
  entry_type VARCHAR(20) NOT NULL, -- sale, payment, adjustment
  reference_id INT,
  debit NUMERIC(12,2) DEFAULT 0,
  credit NUMERIC(12,2) DEFAULT 0,
  balance_after NUMERIC(12,2),
  notes TEXT,
  created_by INT REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── SUPPLIER LEDGER ─────────────────────────────────────
CREATE TABLE supplier_ledgers (
  id SERIAL PRIMARY KEY,
  supplier_id INT REFERENCES suppliers(id),
  entry_type VARCHAR(20) NOT NULL, -- purchase, payment, adjustment
  reference_id INT,
  debit NUMERIC(12,2) DEFAULT 0,
  credit NUMERIC(12,2) DEFAULT 0,
  notes TEXT,
  created_by INT REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── EXPENSES ────────────────────────────────────────────
CREATE TABLE expense_categories (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  is_active BOOLEAN DEFAULT TRUE
);

INSERT INTO expense_categories (name) VALUES
  ('Salary'),('Rent'),('Electricity'),('Water'),
  ('Transport'),('Maintenance'),('Miscellaneous');

CREATE TABLE expenses (
  id SERIAL PRIMARY KEY,
  category_id INT REFERENCES expense_categories(id),
  branch_id INT REFERENCES branches(id),
  description TEXT NOT NULL,
  amount NUMERIC(12,2) NOT NULL,
  payment_method VARCHAR(30) DEFAULT 'cash',
  expense_date DATE DEFAULT CURRENT_DATE,
  created_by INT REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── WASTAGE ─────────────────────────────────────────────
CREATE TABLE wastage_entries (
  id SERIAL PRIMARY KEY,
  product_id INT REFERENCES products(id),
  batch_id INT REFERENCES product_batches(id),
  branch_id INT REFERENCES branches(id),
  wastage_type VARCHAR(30), -- blood_water, trimming, spoilage, expired, damaged, staff_use
  quantity NUMERIC(10,3) NOT NULL,
  estimated_loss NUMERIC(12,2),
  notes TEXT,
  created_by INT REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── CASH SESSIONS ───────────────────────────────────────
CREATE TABLE cash_sessions (
  id SERIAL PRIMARY KEY,
  branch_id INT REFERENCES branches(id),
  cashier_id INT REFERENCES users(id),
  session_date DATE DEFAULT CURRENT_DATE,
  opening_balance NUMERIC(12,2) DEFAULT 0,
  closing_balance NUMERIC(12,2),
  total_cash_sales NUMERIC(12,2) DEFAULT 0,
  total_collected NUMERIC(12,2) DEFAULT 0,
  status VARCHAR(20) DEFAULT 'open', -- open, closed
  opened_at TIMESTAMPTZ DEFAULT NOW(),
  closed_at TIMESTAMPTZ,
  notes TEXT
);

-- ─── ALERTS ──────────────────────────────────────────────
CREATE TABLE alerts (
  id SERIAL PRIMARY KEY,
  alert_type VARCHAR(30) NOT NULL, -- low_stock, near_expiry, khata_due, unusual_wastage, out_of_stock
  severity VARCHAR(10) DEFAULT 'warning', -- info, warning, critical
  branch_id INT REFERENCES branches(id),
  reference_type VARCHAR(30),
  reference_id INT,
  title VARCHAR(200) NOT NULL,
  message TEXT,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── AUDIT LOGS ──────────────────────────────────────────
CREATE TABLE audit_logs (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id),
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(50),
  entity_id INT,
  old_values JSONB,
  new_values JSONB,
  ip_address VARCHAR(50),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── REFRESH TOKENS ──────────────────────────────────────
CREATE TABLE refresh_tokens (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id) ON DELETE CASCADE,
  token VARCHAR(500) UNIQUE NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── INDEXES ─────────────────────────────────────────────
CREATE INDEX idx_sales_branch ON sales(branch_id);
CREATE INDEX idx_sales_date ON sales(sale_date);
CREATE INDEX idx_sales_customer ON sales(customer_id);
CREATE INDEX idx_stock_movements_product ON stock_movements(product_id);
CREATE INDEX idx_stock_movements_branch ON stock_movements(branch_id);
CREATE INDEX idx_product_batches_product ON product_batches(product_id);
CREATE INDEX idx_product_batches_branch ON product_batches(branch_id);
CREATE INDEX idx_customer_ledger_customer ON customer_ledgers(customer_id);
CREATE INDEX idx_alerts_branch ON alerts(branch_id);
CREATE INDEX idx_audit_user ON audit_logs(user_id);

-- ─── SEED BATCHES ─────────────────────────────────────────
INSERT INTO product_batches (batch_code, product_id, branch_id, supplier_id, purchase_date, processing_date, expiry_date, purchase_qty, current_qty, purchase_cost, freshness_status) VALUES
  ('B0035', 1, 2, 1, '2026-04-18', '2026-04-18', '2026-04-20', 20, 4.5,  7200, 'fresh'),
  ('B0034', 3, 2, 2, '2026-04-16', '2026-04-16', '2026-04-20', 15, 8,   10800, 'expiring'),
  ('B0033', 5, 2, 3, '2026-04-17', '2026-04-17', '2026-04-21', 10, 10,   6200, 'fresh'),
  ('B0032', 2, 2, 1, '2026-04-18', '2026-04-18', '2026-04-22', 15, 12,   6150, 'fresh'),
  ('B0031', 4, 2, 2, '2026-04-17', '2026-04-17', '2026-04-21', 10, 5.5,  6800, 'fresh'),
  ('B0030', 6, 2, 4, '2026-04-17', NULL,          '2026-04-25',300,240,   3600, 'fresh');

-- ─── SEED SAMPLE SALES ───────────────────────────────────
INSERT INTO sales (invoice_number, branch_id, customer_id, cashier_id, subtotal, vat_amount, total_amount, paid_amount, payment_method) VALUES
  ('MMN-1042', 2, 1, 3, 902.65, 117.35, 1020, 1020, 'cash'),
  ('MMN-1041', 2, 4, 3, 1194.69, 155.31, 1350, 1350, 'khalti'),
  ('MMN-1040', 2, 2, 3, 4247.79, 552.21, 4800,    0, 'khata'),
  ('MMN-1039', 2, 6, 3,  672.57,  87.43,  760,  760, 'cash'),
  ('MMN-1038', 2, 3, 3, 4778.76, 621.24, 5400, 2700, 'bank');

-- ─── SEED EXPENSES ───────────────────────────────────────
INSERT INTO expenses (category_id, branch_id, description, amount, payment_method, expense_date, created_by) VALUES
  (1, 2, 'Ram Kumar — Cashier salary April',    18000, 'bank',  '2026-04-18', 1),
  (5, 2, 'Meat delivery transport from Kalimati',  800, 'cash',  '2026-04-18', 2),
  (3, 2, 'April NEA electricity bill',           3200, 'esewa', '2026-04-17', 2),
  (2, 2, 'Baneshwor shop monthly rent',         15000, 'bank',  '2026-04-15', 1),
  (7, 2, 'Cleaning supplies and disinfectant',    450, 'cash',  '2026-04-14', 4);

-- ─── SEED ALERTS ─────────────────────────────────────────
INSERT INTO alerts (alert_type, severity, branch_id, title, message) VALUES
  ('low_stock',    'critical', 2, 'Broiler Chicken — Low Stock',         'Only 4.5 kg remaining. Threshold is 5 kg. Order immediately.'),
  ('near_expiry',  'warning',  2, 'Mutton Batch #B0034 — Near Expiry',   'Expires in 2 days. 8 kg remaining. Consider discount pricing.'),
  ('khata_due',    'warning',  2, 'Hotel Shivam — Overdue Khata',        'NPR 4,800 overdue since April 10. 8 days past due date.');

SELECT 'Database setup complete!' AS status;
