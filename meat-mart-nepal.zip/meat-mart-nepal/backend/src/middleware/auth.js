const jwt = require('jsonwebtoken');
const pool = require('../db/pool');

const auth = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'No token provided' });
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Get fresh user from DB
    const result = await pool.query(
      `SELECT u.id, u.full_name, u.email, u.role_id, u.branch_id, u.is_active,
              r.name AS role_name, r.permissions,
              b.name AS branch_name
       FROM users u
       JOIN roles r ON u.role_id = r.id
       LEFT JOIN branches b ON u.branch_id = b.id
       WHERE u.id = $1 AND u.is_active = TRUE`,
      [decoded.userId]
    );

    if (!result.rows.length) {
      return res.status(401).json({ error: 'User not found or inactive' });
    }

    req.user = result.rows[0];
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token expired', code: 'TOKEN_EXPIRED' });
    }
    return res.status(401).json({ error: 'Invalid token' });
  }
};

// Role-based access
const requireRole = (...roles) => (req, res, next) => {
  if (!req.user) return res.status(401).json({ error: 'Unauthorized' });
  const userRole = req.user.role_name;
  if (userRole === 'admin') return next(); // admin bypasses all
  if (!roles.includes(userRole)) {
    return res.status(403).json({ error: 'Insufficient permissions' });
  }
  next();
};

// Branch access — admin sees all, others see own branch
const branchFilter = (req) => {
  if (req.user.role_name === 'admin') {
    return req.query.branch_id ? parseInt(req.query.branch_id) : null;
  }
  return req.user.branch_id;
};

module.exports = { auth, requireRole, branchFilter };
