const express = require('express');
const pool = require('../db/pool');
const { auth, requireRole, branchFilter } = require('../middleware/auth');

const router = express.Router();

// ─── INVENTORY ────────────────────────────────────────────────

// GET /api/inventory/batches
router.get('/batches', auth, async (req, res) => {
  try {
    const branchId = branchFilter(req);
    const params = branchId ? [branchId] : [];
    const result = await pool.query(
      `SELECT pb.*, p.name AS product_name, p.emoji, p.unit, p.low_stock_threshold,
              b.name AS branch_name, s.name AS supplier_name,
              CASE WHEN pb.expiry_date < CURRENT_DATE THEN 'expired'
                   WHEN pb.expiry_date <= CURRENT_DATE + INTERVAL '3 days' THEN 'expiring'
                   ELSE 'fresh' END AS computed_freshness,
              CASE WHEN pb.current_qty <= p.low_stock_threshold THEN TRUE ELSE FALSE END AS is_low
       FROM product_batches pb
       JOIN products p ON pb.product_id = p.id
       JOIN branches b ON pb.branch_id = b.id
       LEFT JOIN suppliers s ON pb.supplier_id = s.id
       WHERE pb.is_active = TRUE ${branchId ? 'AND pb.branch_id = $1' : ''}
       ORDER BY pb.expiry_date ASC, p.name`,
      params
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/inventory/movements
router.get('/movements', auth, async (req, res) => {
  try {
    const branchId = branchFilter(req);
    const params = branchId ? [branchId] : [];
    const result = await pool.query(
      `SELECT sm.*, p.name AS product_name, p.emoji, pb.batch_code,
              b.name AS branch_name, u.full_name AS created_by_name
       FROM stock_movements sm
       JOIN products p ON sm.product_id = p.id
       JOIN branches b ON sm.branch_id = b.id
       LEFT JOIN product_batches pb ON sm.batch_id = pb.id
       LEFT JOIN users u ON sm.created_by = u.id
       WHERE 1=1 ${branchId ? 'AND sm.branch_id = $1' : ''}
       ORDER BY sm.created_at DESC LIMIT 50`,
      params
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/inventory/receive — receive stock
router.post('/receive', auth, requireRole('admin', 'manager', 'storekeeper'), async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { product_id, supplier_id, quantity, purchase_cost, purchase_date,
            processing_date, expiry_date, batch_code, notes } = req.body;
    const branchId = req.user.branch_id || req.body.branch_id;

    const bc = batch_code || `B${Date.now().toString().slice(-5)}`;

    const batch = await client.query(
      `INSERT INTO product_batches (batch_code, product_id, branch_id, supplier_id,
        purchase_date, processing_date, expiry_date, purchase_qty, current_qty,
        purchase_cost, notes)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$8,$9,$10) RETURNING *`,
      [bc, product_id, branchId, supplier_id, purchase_date || new Date(),
       processing_date, expiry_date, quantity, purchase_cost, notes]
    );

    await client.query(
      `INSERT INTO stock_movements (product_id, branch_id, batch_id, movement_type, quantity,
        reference_type, created_by)
       VALUES ($1,$2,$3,'purchase_in',$4,'purchase',$5)`,
      [product_id, branchId, batch.rows[0].id, quantity, req.user.id]
    );

    await client.query('COMMIT');
    res.status(201).json(batch.rows[0]);
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: 'Server error' });
  } finally {
    client.release();
  }
});

// POST /api/inventory/wastage
router.post('/wastage', auth, requireRole('admin', 'manager', 'storekeeper'), async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { product_id, batch_id, wastage_type, quantity, notes } = req.body;
    const branchId = req.user.branch_id || req.body.branch_id;

    const product = await client.query('SELECT * FROM products WHERE id = $1', [product_id]);
    const estimated_loss = product.rows[0] ? product.rows[0].purchase_cost * quantity : 0;

    const wastage = await client.query(
      `INSERT INTO wastage_entries (product_id, batch_id, branch_id, wastage_type,
        quantity, estimated_loss, notes, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [product_id, batch_id, branchId, wastage_type, quantity, estimated_loss, notes, req.user.id]
    );

    if (batch_id) {
      await client.query(
        'UPDATE product_batches SET current_qty = current_qty - $1 WHERE id = $2',
        [quantity, batch_id]
      );
    }

    await client.query(
      `INSERT INTO stock_movements (product_id, branch_id, batch_id, movement_type, quantity,
        reference_type, reference_id, created_by)
       VALUES ($1,$2,$3,'wastage',$4,'wastage',$5,$6)`,
      [product_id, branchId, batch_id, -quantity, wastage.rows[0].id, req.user.id]
    );

    await client.query('COMMIT');
    res.status(201).json(wastage.rows[0]);
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: 'Server error' });
  } finally {
    client.release();
  }
});

module.exports = router;
