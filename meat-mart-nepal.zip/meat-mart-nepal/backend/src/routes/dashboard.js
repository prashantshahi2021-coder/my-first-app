const express = require('express');
const pool = require('../db/pool');
const { auth, branchFilter } = require('../middleware/auth');

const router = express.Router();

// GET /api/dashboard/stats
router.get('/stats', auth, async (req, res) => {
  try {
    const branchId = branchFilter(req);
    const branchClause = branchId ? 'AND branch_id = $1' : '';
    const params = branchId ? [branchId] : [];

    // Today's sales
    const todaySales = await pool.query(
      `SELECT COALESCE(SUM(total_amount),0) AS revenue, COUNT(*) AS bills
       FROM sales WHERE DATE(sale_date) = CURRENT_DATE ${branchClause}`,
      params
    );

    // Khata due
    const khataDue = await pool.query(
      `SELECT COALESCE(SUM(due_amount),0) AS total_due FROM sales
       WHERE due_amount > 0 ${branchClause}`,
      params
    );

    // Active alerts
    const alertsCount = await pool.query(
      `SELECT COUNT(*) AS total FROM alerts WHERE is_read = FALSE ${branchId ? 'AND branch_id = $1' : ''}`,
      params
    );

    // Weekly sales (last 7 days)
    const weeklySales = await pool.query(
      `SELECT DATE(sale_date) AS day, COALESCE(SUM(total_amount),0) AS revenue
       FROM sales
       WHERE sale_date >= NOW() - INTERVAL '7 days' ${branchClause}
       GROUP BY DATE(sale_date) ORDER BY day`,
      params
    );

    // Recent sales
    const recentSales = await pool.query(
      `SELECT s.id, s.invoice_number, c.name AS customer_name,
              s.total_amount, s.payment_method, s.due_amount,
              s.sale_date, b.name AS branch_name
       FROM sales s
       JOIN customers c ON s.customer_id = c.id
       JOIN branches b ON s.branch_id = b.id
       WHERE 1=1 ${branchClause}
       ORDER BY s.sale_date DESC LIMIT 10`,
      params
    );

    // Active alerts list
    const alertsList = await pool.query(
      `SELECT a.*, b.name AS branch_name FROM alerts a
       LEFT JOIN branches b ON a.branch_id = b.id
       WHERE a.is_read = FALSE ${branchId ? 'AND a.branch_id = $1' : ''}
       ORDER BY a.created_at DESC LIMIT 10`,
      params
    );

    // Branch revenue (admin only)
    let branchRevenue = [];
    if (!branchId) {
      const br = await pool.query(
        `SELECT b.name, COALESCE(SUM(s.total_amount),0) AS revenue
         FROM branches b LEFT JOIN sales s ON s.branch_id = b.id AND DATE(s.sale_date) = CURRENT_DATE
         WHERE b.is_warehouse = FALSE GROUP BY b.id, b.name ORDER BY revenue DESC`
      );
      branchRevenue = br.rows;
    }

    // Cash session
    const cashSession = await pool.query(
      `SELECT *, 
              (opening_balance + total_cash_sales + total_collected) AS expected_total
       FROM cash_sessions
       WHERE DATE(session_date) = CURRENT_DATE AND status = 'open' ${branchClause}
       LIMIT 1`,
      params
    );

    // Monthly summary
    const monthly = await pool.query(
      `SELECT 
        COALESCE(SUM(total_amount),0) AS revenue,
        COALESCE(SUM(vat_amount),0) AS vat_collected
       FROM sales
       WHERE DATE_TRUNC('month', sale_date) = DATE_TRUNC('month', NOW()) ${branchClause}`,
      params
    );

    res.json({
      today: {
        revenue: parseFloat(todaySales.rows[0].revenue),
        bills: parseInt(todaySales.rows[0].bills)
      },
      khata_due: parseFloat(khataDue.rows[0].total_due),
      alerts_count: parseInt(alertsCount.rows[0].total),
      weekly_sales: weeklySales.rows,
      recent_sales: recentSales.rows,
      alerts: alertsList.rows,
      branch_revenue: branchRevenue,
      cash_session: cashSession.rows[0] || null,
      monthly: monthly.rows[0]
    });
  } catch (err) {
    console.error('Dashboard stats error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
