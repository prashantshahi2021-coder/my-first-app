const express = require('express');
const pool = require('../db/pool');
const { auth, requireRole, branchFilter } = require('../middleware/auth');

const router = express.Router();

// ─── CUSTOMERS ────────────────────────────────────────────────

router.get('/customers', auth, async (req, res) => {
  try {
    const branchId = branchFilter(req);
    const params = branchId ? [branchId] : [];
    const result = await pool.query(
      `SELECT c.*,
              COALESCE(SUM(s.due_amount),0) AS total_due,
              MAX(s.sale_date) AS last_purchase_date
       FROM customers c
       LEFT JOIN sales s ON s.customer_id = c.id
       WHERE c.is_active = TRUE ${branchId ? 'AND (c.branch_id = $1 OR c.branch_id IS NULL)' : ''}
       GROUP BY c.id ORDER BY total_due DESC, c.name`,
      params
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

router.post('/customers', auth, requireRole('admin','manager','cashier'), async (req, res) => {
  try {
    const { name, phone, address, customer_type, credit_limit, notes } = req.body;
    const branchId = req.user.branch_id || req.body.branch_id;
    const result = await pool.query(
      `INSERT INTO customers (name, phone, address, customer_type, branch_id, credit_limit, notes)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [name, phone, address, customer_type || 'retail', branchId, credit_limit || 0, notes]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Khata collection
router.post('/customers/:id/collect', auth, requireRole('admin','manager','cashier'), async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { amount, payment_method, notes } = req.body;
    const branchId = req.user.branch_id || req.body.branch_id;

    await client.query(
      `INSERT INTO customer_ledgers (customer_id, branch_id, entry_type, debit, credit, notes, created_by)
       VALUES ($1,$2,'payment',0,$3,$4,$5)`,
      [req.params.id, branchId, amount, notes || 'Khata collection', req.user.id]
    );

    // Reduce oldest dues on sales
    await client.query(
      `UPDATE sales SET paid_amount = LEAST(total_amount, paid_amount + $1)
       WHERE customer_id = $2 AND due_amount > 0
       ORDER BY sale_date ASC LIMIT 1`,
      [amount, req.params.id]
    );

    await client.query('COMMIT');
    res.json({ message: 'Payment recorded', amount });
  } catch (err) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: 'Server error' });
  } finally {
    client.release();
  }
});

// ─── BRANCHES ─────────────────────────────────────────────────

router.get('/branches', auth, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT b.*,
              COALESCE(SUM(s.total_amount) FILTER (WHERE DATE(s.sale_date)=CURRENT_DATE),0) AS today_revenue,
              COUNT(DISTINCT s.id) FILTER (WHERE DATE(s.sale_date)=CURRENT_DATE) AS today_bills,
              COUNT(DISTINCT al.id) FILTER (WHERE al.is_read=FALSE) AS active_alerts
       FROM branches b
       LEFT JOIN sales s ON s.branch_id = b.id
       LEFT JOIN alerts al ON al.branch_id = b.id
       GROUP BY b.id ORDER BY b.id`
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

router.post('/branches', auth, requireRole('admin'), async (req, res) => {
  try {
    const { name, address, phone, manager_name } = req.body;
    const result = await pool.query(
      `INSERT INTO branches (name, address, phone, manager_name)
       VALUES ($1,$2,$3,$4) RETURNING *`,
      [name, address, phone, manager_name]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// ─── EXPENSES ─────────────────────────────────────────────────

router.get('/expenses', auth, async (req, res) => {
  try {
    const branchId = branchFilter(req);
    const params = branchId ? [branchId] : [];
    const result = await pool.query(
      `SELECT e.*, ec.name AS category_name, b.name AS branch_name, u.full_name AS created_by_name
       FROM expenses e
       JOIN expense_categories ec ON e.category_id = ec.id
       JOIN branches b ON e.branch_id = b.id
       LEFT JOIN users u ON e.created_by = u.id
       WHERE 1=1 ${branchId ? 'AND e.branch_id = $1' : ''}
       ORDER BY e.expense_date DESC, e.created_at DESC LIMIT 100`,
      params
    );

    // Monthly stats
    const stats = await pool.query(
      `SELECT ec.name AS category, COALESCE(SUM(e.amount),0) AS total
       FROM expenses e JOIN expense_categories ec ON e.category_id = ec.id
       WHERE DATE_TRUNC('month', e.expense_date) = DATE_TRUNC('month', NOW())
       ${branchId ? 'AND e.branch_id = $1' : ''}
       GROUP BY ec.name ORDER BY total DESC`,
      params
    );

    res.json({ expenses: result.rows, category_stats: stats.rows });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

router.post('/expenses', auth, requireRole('admin','manager'), async (req, res) => {
  try {
    const { category_id, description, amount, payment_method, expense_date, notes } = req.body;
    const branchId = req.user.branch_id || req.body.branch_id;
    const result = await pool.query(
      `INSERT INTO expenses (category_id, branch_id, description, amount, payment_method, expense_date, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [category_id, branchId, description, amount, payment_method || 'cash',
       expense_date || new Date(), req.user.id]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

router.get('/expense-categories', auth, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM expense_categories WHERE is_active=TRUE ORDER BY name');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// ─── ALERTS ───────────────────────────────────────────────────

router.get('/alerts', auth, async (req, res) => {
  try {
    const branchId = branchFilter(req);
    const params = branchId ? [branchId] : [];
    const result = await pool.query(
      `SELECT a.*, b.name AS branch_name FROM alerts a
       LEFT JOIN branches b ON a.branch_id = b.id
       WHERE 1=1 ${branchId ? 'AND a.branch_id = $1' : ''}
       ORDER BY a.created_at DESC LIMIT 100`,
      params
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

router.put('/alerts/:id/read', auth, async (req, res) => {
  try {
    await pool.query('UPDATE alerts SET is_read = TRUE WHERE id = $1', [req.params.id]);
    res.json({ message: 'Alert marked as read' });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// ─── SUPPLIERS ────────────────────────────────────────────────

router.get('/suppliers', auth, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT s.*,
              COALESCE(SUM(p.total_amount - p.paid_amount),0) AS total_due,
              COUNT(p.id) AS total_purchases
       FROM suppliers s
       LEFT JOIN purchases p ON p.supplier_id = s.id
       WHERE s.is_active = TRUE
       GROUP BY s.id ORDER BY s.name`
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// ─── REPORTS ──────────────────────────────────────────────────

router.get('/reports/sales', auth, async (req, res) => {
  try {
    const branchId = branchFilter(req);
    const { period = 'month' } = req.query;
    const params = branchId ? [branchId] : [];

    const interval = period === 'week' ? '7 days' : period === 'year' ? '365 days' : '30 days';

    const summary = await pool.query(
      `SELECT 
        COALESCE(SUM(total_amount),0) AS revenue,
        COALESCE(SUM(vat_amount),0) AS vat,
        COALESCE(SUM(discount_amount),0) AS discounts,
        COUNT(*) AS total_bills,
        COALESCE(AVG(total_amount),0) AS avg_bill
       FROM sales
       WHERE sale_date >= NOW() - INTERVAL '${interval}'
       ${branchId ? 'AND branch_id = $1' : ''}`,
      params
    );

    const byProduct = await pool.query(
      `SELECT p.name, p.emoji, SUM(si.quantity) AS qty_sold,
              SUM(si.line_total) AS revenue
       FROM sale_items si
       JOIN products p ON si.product_id = p.id
       JOIN sales s ON si.sale_id = s.id
       WHERE s.sale_date >= NOW() - INTERVAL '${interval}'
       ${branchId ? 'AND s.branch_id = $1' : ''}
       GROUP BY p.id ORDER BY revenue DESC`,
      params
    );

    const byPayment = await pool.query(
      `SELECT payment_method, COUNT(*) AS count, SUM(total_amount) AS total
       FROM sales
       WHERE sale_date >= NOW() - INTERVAL '${interval}'
       ${branchId ? 'AND branch_id = $1' : ''}
       GROUP BY payment_method ORDER BY total DESC`,
      params
    );

    const wastageTotal = await pool.query(
      `SELECT COALESCE(SUM(quantity),0) AS total_qty,
              COALESCE(SUM(estimated_loss),0) AS total_loss
       FROM wastage_entries
       WHERE created_at >= NOW() - INTERVAL '${interval}'
       ${branchId ? 'AND branch_id = $1' : ''}`,
      params
    );

    const purchaseTotal = await pool.query(
      `SELECT COALESCE(SUM(total_amount),0) AS total
       FROM purchases
       WHERE purchase_date >= CURRENT_DATE - INTERVAL '${interval}'
       ${branchId ? 'AND branch_id = $1' : ''}`,
      params
    );

    const expenseTotal = await pool.query(
      `SELECT COALESCE(SUM(amount),0) AS total FROM expenses
       WHERE expense_date >= CURRENT_DATE - INTERVAL '${interval}'
       ${branchId ? 'AND branch_id = $1' : ''}`,
      params
    );

    res.json({
      summary: summary.rows[0],
      by_product: byProduct.rows,
      by_payment: byPayment.rows,
      wastage: wastageTotal.rows[0],
      purchases: purchaseTotal.rows[0],
      expenses: expenseTotal.rows[0]
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ─── USERS (admin) ────────────────────────────────────────────

router.get('/users', auth, requireRole('admin'), async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT u.id, u.full_name, u.email, u.is_active, u.last_login, u.created_at,
              r.name AS role_name, b.name AS branch_name
       FROM users u JOIN roles r ON u.role_id = r.id
       LEFT JOIN branches b ON u.branch_id = b.id
       ORDER BY u.created_at DESC`
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
