const express = require('express');
const pool = require('../db/pool');
const { auth, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/products
router.get('/', auth, async (req, res) => {
  try {
    const { category, active } = req.query;
    let q = `SELECT p.*, pc.name AS category_name, pc.slug AS category_slug, pc.emoji AS category_emoji,
             ARRAY_AGG(DISTINCT cut.cut_name) FILTER (WHERE cut.id IS NOT NULL) AS cuts
             FROM products p
             JOIN product_categories pc ON p.category_id = pc.id
             LEFT JOIN product_cuts cut ON p.id = cut.product_id
             WHERE 1=1`;
    const params = [];

    if (category) { params.push(category); q += ` AND pc.slug = $${params.length}`; }
    if (active !== undefined) { params.push(active === 'true'); q += ` AND p.is_active = $${params.length}`; }

    q += ' GROUP BY p.id, pc.id ORDER BY pc.sort_order, p.name';

    const result = await pool.query(q, params);
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/products/:id
router.get('/:id', auth, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT p.*, pc.name AS category_name, pc.emoji AS category_emoji,
              JSON_AGG(DISTINCT JSONB_BUILD_OBJECT('id', cut.id, 'name', cut.cut_name, 'extra', cut.extra_charge))
                FILTER (WHERE cut.id IS NOT NULL) AS cuts
       FROM products p
       JOIN product_categories pc ON p.category_id = pc.id
       LEFT JOIN product_cuts cut ON p.id = cut.product_id
       WHERE p.id = $1 GROUP BY p.id, pc.id`,
      [req.params.id]
    );
    if (!result.rows.length) return res.status(404).json({ error: 'Product not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/products
router.post('/', auth, requireRole('admin', 'manager'), async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { name, category_id, sku, emoji, sale_mode, unit, sale_price, purchase_cost,
            vat_applicable, low_stock_threshold, notes, cuts } = req.body;

    const result = await client.query(
      `INSERT INTO products (name, category_id, sku, emoji, sale_mode, unit, sale_price,
        purchase_cost, vat_applicable, low_stock_threshold, notes)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
      [name, category_id, sku, emoji || '🥩', sale_mode || 'weight', unit || 'kg',
       sale_price, purchase_cost, vat_applicable !== false, low_stock_threshold || 5, notes]
    );

    const product = result.rows[0];

    if (cuts && cuts.length > 0) {
      for (const cut of cuts) {
        await client.query(
          'INSERT INTO product_cuts (product_id, cut_name, extra_charge) VALUES ($1,$2,$3)',
          [product.id, cut.name || cut, cut.extra_charge || 0]
        );
      }
    }

    await client.query('COMMIT');
    res.status(201).json(product);
  } catch (err) {
    await client.query('ROLLBACK');
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  } finally {
    client.release();
  }
});

// PUT /api/products/:id
router.put('/:id', auth, requireRole('admin', 'manager'), async (req, res) => {
  try {
    const { name, category_id, sku, unit, sale_price, purchase_cost,
            vat_applicable, low_stock_threshold, is_active, notes } = req.body;

    const result = await pool.query(
      `UPDATE products SET name=$1, category_id=$2, sku=$3, unit=$4, sale_price=$5,
       purchase_cost=$6, vat_applicable=$7, low_stock_threshold=$8, is_active=$9,
       notes=$10 WHERE id=$11 RETURNING *`,
      [name, category_id, sku, unit, sale_price, purchase_cost,
       vat_applicable, low_stock_threshold, is_active, notes, req.params.id]
    );

    if (!result.rows.length) return res.status(404).json({ error: 'Product not found' });
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/products/categories/all
router.get('/categories/all', auth, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM product_categories ORDER BY sort_order');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
