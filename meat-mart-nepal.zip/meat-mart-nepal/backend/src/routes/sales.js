const express = require('express');
const pool = require('../db/pool');
const { auth, requireRole, branchFilter } = require('../middleware/auth');

const router = express.Router();

// GET /api/sales
router.get('/', auth, async (req, res) => {
  try {
    const branchId = branchFilter(req);
    const { limit = 50, offset = 0, date_from, date_to, customer_id } = req.query;
    let params = [], conditions = [];

    if (branchId) { params.push(branchId); conditions.push(`s.branch_id = $${params.length}`); }
    if (date_from) { params.push(date_from); conditions.push(`DATE(s.sale_date) >= $${params.length}`); }
    if (date_to)   { params.push(date_to);   conditions.push(`DATE(s.sale_date) <= $${params.length}`); }
    if (customer_id) { params.push(customer_id); conditions.push(`s.customer_id = $${params.length}`); }

    const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : '';
    params.push(limit, offset);

    const result = await pool.query(
      `SELECT s.*, c.name AS customer_name, b.name AS branch_name, u.full_name AS cashier_name
       FROM sales s
       JOIN customers c ON s.customer_id = c.id
       JOIN branches b ON s.branch_id = b.id
       JOIN users u ON s.cashier_id = u.id
       ${where}
       ORDER BY s.sale_date DESC
       LIMIT $${params.length - 1} OFFSET $${params.length}`,
      params
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/sales/:id
router.get('/:id', auth, async (req, res) => {
  try {
    const sale = await pool.query(
      `SELECT s.*, c.name AS customer_name, c.phone AS customer_phone,
              b.name AS branch_name, u.full_name AS cashier_name
       FROM sales s
       JOIN customers c ON s.customer_id = c.id
       JOIN branches b ON s.branch_id = b.id
       JOIN users u ON s.cashier_id = u.id
       WHERE s.id = $1`, [req.params.id]
    );
    if (!sale.rows.length) return res.status(404).json({ error: 'Sale not found' });

    const items = await pool.query(
      `SELECT si.*, p.name AS product_name, p.emoji, p.unit
       FROM sale_items si JOIN products p ON si.product_id = p.id
       WHERE si.sale_id = $1`, [req.params.id]
    );

    res.json({ ...sale.rows[0], items: items.rows });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /api/sales — Create new sale
router.post('/', auth, requireRole('admin', 'manager', 'cashier'), async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const { customer_id, items, payment_method, paid_amount, notes } = req.body;
    const branchId = req.user.branch_id || req.body.branch_id;

    if (!items || !items.length) {
      return res.status(400).json({ error: 'No items in sale' });
    }

    // Generate invoice number
    const countRes = await client.query('SELECT COUNT(*) FROM sales');
    const invoiceNum = `MMN-${String(parseInt(countRes.rows[0].count) + 1043).padStart(4, '0')}`;

    // Calculate totals
    let subtotal = 0;
    for (const item of items) {
      subtotal += item.quantity * item.unit_price - (item.discount || 0);
    }
    const vatAmount = items.some(i => i.vat_applicable) ? subtotal * 0.13 : 0;
    const totalAmount = subtotal + vatAmount;
    const paidAmt = paid_amount !== undefined ? parseFloat(paid_amount) : totalAmount;
    const isKhata = payment_method === 'khata' || paidAmt < totalAmount;

    // Insert sale
    const saleResult = await client.query(
      `INSERT INTO sales (invoice_number, branch_id, customer_id, cashier_id, subtotal,
        vat_amount, total_amount, paid_amount, payment_method, is_khata, notes)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
      [invoiceNum, branchId, customer_id || 1, req.user.id,
       subtotal, vatAmount, totalAmount, paidAmt, payment_method || 'cash', isKhata, notes]
    );

    const sale = saleResult.rows[0];

    // Insert items & update stock
    for (const item of items) {
      await client.query(
        `INSERT INTO sale_items (sale_id, product_id, batch_id, cut_type, quantity, unit_price, discount, vat_rate)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
        [sale.id, item.product_id, item.batch_id || null, item.cut_type || null,
         item.quantity, item.unit_price, item.discount || 0, item.vat_applicable ? 13 : 0]
      );

      // Deduct stock from batch if batch provided
      if (item.batch_id) {
        await client.query(
          'UPDATE product_batches SET current_qty = current_qty - $1 WHERE id = $2',
          [item.quantity, item.batch_id]
        );
      }

      // Stock movement record
      await client.query(
        `INSERT INTO stock_movements (product_id, branch_id, batch_id, movement_type, quantity,
          reference_type, reference_id, created_by)
         VALUES ($1,$2,$3,'sale_out',$4,'sale',$5,$6)`,
        [item.product_id, branchId, item.batch_id || null, -item.quantity, sale.id, req.user.id]
      );
    }

    // Update customer khata if on credit
    if (isKhata && customer_id && customer_id !== 1) {
      await client.query(
        `INSERT INTO customer_ledgers (customer_id, branch_id, entry_type, reference_id, debit, notes, created_by)
         VALUES ($1,$2,'sale',$3,$4,'Sale on credit',$5)`,
        [customer_id, branchId, sale.id, totalAmount - paidAmt, req.user.id]
      );
    }

    // Audit log
    await client.query(
      `INSERT INTO audit_logs (user_id, action, entity_type, entity_id, new_values)
       VALUES ($1,'CREATE_SALE','sale',$2,$3)`,
      [req.user.id, sale.id, JSON.stringify({ invoice: invoiceNum, total: totalAmount })]
    );

    await client.query('COMMIT');
    res.status(201).json(sale);
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Sale error:', err);
    res.status(500).json({ error: 'Server error' });
  } finally {
    client.release();
  }
});

module.exports = router;
