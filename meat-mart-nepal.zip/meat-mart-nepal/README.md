# 🥩 Meat Mart Nepal — Retail Management System

A production-grade, multi-branch meat retail management system built with HTML/CSS/JavaScript frontend and Node.js/Express/PostgreSQL backend.

---

## 🚀 Quick Start

### Option A — Run with Docker (Recommended, easiest)

**Prerequisites:** Docker + Docker Compose installed

```bash
# 1. Copy .env file
cp backend/.env.example backend/.env

# 2. Start everything (DB + API + Nginx)
docker-compose up -d

# 3. Open browser
open http://localhost
```

### Option B — Run without Docker (Manual)

**Prerequisites:** Node.js 18+, PostgreSQL 14+

#### Step 1 — Setup Database
```bash
# Create database
psql -U postgres -c "CREATE DATABASE meatmart;"

# Run schema (creates all tables + seed data)
psql -U postgres -d meatmart -f database/schema.sql
```

#### Step 2 — Setup Backend
```bash
cd backend

# Install dependencies
npm install

# Copy and edit .env
cp .env.example .env
# Edit .env → set DB_PASSWORD, JWT_SECRET, JWT_REFRESH_SECRET

# Start API server
npm run dev       # development (auto-restart)
npm start         # production
```

#### Step 3 — Serve Frontend
```bash
# Option 1: Use VS Code Live Server (simplest)
# Right-click frontend/index.html → Open with Live Server

# Option 2: Serve with Node (from root)
cd frontend
npx serve . -p 3000

# Option 3: The backend already serves frontend at http://localhost:5000
```

---

## 🔐 Default Login Credentials

| Role        | Email                  | Password     | Access              |
|-------------|------------------------|--------------|---------------------|
| Admin       | admin@meatmart.np      | Admin@1234   | All branches + full |
| Manager     | sushil@meatmart.np     | Admin@1234   | Baneshwor branch    |
| Cashier     | ram@meatmart.np        | Admin@1234   | Baneshwor POS       |
| Storekeeper | gopal@meatmart.np      | Admin@1234   | Kalanki inventory   |

> ⚠️ **Change all passwords after first login in production!**

---

## 🌐 Offline / Demo Mode

The app works **without a backend** too. If the API is unreachable:
- Login still works with the demo credentials above
- All pages load with realistic mock data
- POS checkout, product add, expense entry all work locally
- Data is not persisted across sessions (resets on refresh)

---

## 📁 Project Structure

```
meat-mart-nepal/
├── frontend/                 # Pure HTML/CSS/JS frontend
│   ├── index.html            # Main app shell (all pages)
│   ├── login.html            # Login page
│   ├── css/
│   │   └── main.css          # Complete design system
│   └── js/
│       ├── api.js            # HTTP client + auth token management
│       ├── app.js            # Navigation, branch switcher, helpers
│       ├── pages1.js         # Dashboard, POS, Inventory
│       └── pages2.js         # Products, Customers, Expenses, Reports, Alerts, Branches
│
├── backend/                  # Node.js + Express API
│   ├── src/
│   │   ├── server.js         # Main Express server
│   │   ├── db/pool.js        # PostgreSQL connection pool
│   │   ├── middleware/auth.js # JWT verification + RBAC
│   │   └── routes/
│   │       ├── auth.js       # Login, refresh, logout
│   │       ├── dashboard.js  # Dashboard stats
│   │       ├── products.js   # Product CRUD
│   │       ├── sales.js      # POS sales creation
│   │       ├── inventory.js  # Batches, movements, wastage
│   │       └── misc.js       # Customers, branches, expenses, alerts, reports
│   ├── .env.example
│   ├── Dockerfile
│   └── package.json
│
├── database/
│   └── schema.sql            # Full PostgreSQL schema + seed data
│
├── docker/
│   └── nginx.conf            # Nginx reverse proxy config
│
└── docker-compose.yml        # Full stack compose file
```

---

## 🏗️ Tech Stack

| Layer     | Technology                           |
|-----------|--------------------------------------|
| Frontend  | HTML5, CSS3, Vanilla JavaScript (ES6+)|
| Backend   | Node.js, Express.js                  |
| Database  | PostgreSQL 15                        |
| Auth      | JWT + Refresh Tokens                 |
| Proxy     | Nginx                                |
| Container | Docker + Docker Compose              |

---

## ✅ Modules Included (Phase 1 Complete)

| Module           | Status | Features |
|------------------|--------|---------|
| Authentication   | ✅ | JWT, roles, refresh tokens, auto-logout |
| Branch Switcher  | ✅ | Admin sees all branches, staff see own |
| Dashboard        | ✅ | Revenue, bills, khata, alerts, weekly chart |
| POS / Billing    | ✅ | Cart, 6 payment methods, VAT, invoice |
| Inventory        | ✅ | Batch cards, freshness, stock bars, movements |
| Products         | ✅ | Full catalog, cuts, pricing, VAT flags |
| Customers        | ✅ | All types, due tracking, khata |
| Khata Ledger     | ✅ | Overdue tracking, collection |
| Expenses         | ✅ | Categories, quick-add, monthly breakdown |
| Reports          | ✅ | Revenue, profit, wastage, product & payment breakdown |
| Alerts           | ✅ | Critical/warning tiers, history, mark-read |
| Branches         | ✅ | Branch cards, transfer requests |
| Employees        | ✅ | Staff list, attendance, audit log |
| Settings         | ✅ | Shop info, tax config, user management |
| Purchases        | ✅ | PO list, GRN tracking |

---

## 🔒 Security

- Passwords hashed with bcrypt (cost factor 10)
- JWT access tokens expire in 8 hours
- Refresh tokens stored in DB, expire in 30 days
- RBAC: admin/manager/cashier/storekeeper roles
- Rate limiting on auth endpoints (20 req/15min)
- Helmet.js security headers
- Branch-level data isolation for non-admin users

---

## 📦 Deployment to VPS

```bash
# On Ubuntu VPS:
sudo apt install docker.io docker-compose -y

# Clone / upload project
scp -r meat-mart-nepal/ user@your-vps-ip:/app/

# Edit production secrets
nano /app/meat-mart-nepal/backend/.env
# Set strong JWT_SECRET, JWT_REFRESH_SECRET, DB_PASSWORD
# Set FRONTEND_URL=https://yourdomain.com

# Start
cd /app/meat-mart-nepal
docker-compose up -d

# For SSL (after pointing domain to VPS):
# Add certbot/Let's Encrypt to nginx config
```

---

## 🛠️ Development

```bash
# Backend dev server with auto-reload
cd backend && npm run dev

# Watch API logs
docker-compose logs -f api

# Connect to DB directly
docker-compose exec db psql -U postgres meatmart

# Reset database
docker-compose down -v && docker-compose up -d
```

---

## 📞 Support

Built for Meat Mart Nepal retail operations.
For Phase 2 (Supplier khata, wastage module, stock transfers) and Phase 3 (WhatsApp alerts, offline sync, advanced analytics) — extend from this foundation.
